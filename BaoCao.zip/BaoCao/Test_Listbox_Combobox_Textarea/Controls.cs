﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Test_Listbox_Combobox_Textarea
{
    class Controls
    {
        //load du lieu tu file text len listbox
        public void LoadToListBox(ListBox lbx, string TenFile)
        {
            StreamReader sr = new StreamReader(TenFile);
            string Line = sr.ReadLine();
            while (Line != null && Line != " ")
            {
                lbx.Items.Add(Line);
                Line = sr.ReadLine();
            }
            sr.Close();
        }

        //ghi du lieu vao file tu listbox
        public void WriteListBoxToFile(ListBox lbx, string pathFile)
        {
            StreamWriter sw = new StreamWriter(pathFile);
            string Line;
            for (int i = 0; i < lbx.Items.Count; ++i)
            {
                Line = "";
                Line += lbx.Items[i];
                sw.WriteLine(Line);
            }
            sw.Close();
        }

        //ghi truc tiep vao file.
        public void WriteDirectlyToFile(ListBox lbx, int n, int m, string pathFile)
        {
            StreamWriter sw = new StreamWriter(pathFile);
            string Line, street = "";
            for (int i = 0; i < lbx.Items.Count; ++i)
            {
                Line = "";
                street = lbx.Items[i].ToString();
                string[] chuoi = street.Split('|');
                Line += chuoi[n].Substring(m).Trim();
                sw.WriteLine(Line);
            }
            sw.Close();
        }

        //ghi noi du lieu
        //public void SavedataToFile(string TenFile, string Dulieu)
        //{
        //    StreamWriter sw = File.AppendText(TenFile);
        //    sw.WriteLine(Dulieu);
        //    sw.Close();
        //}

        //chen du lieu vao combobox
        public void AdddatainCb(ComboBox cb, string TenFile)
        {

            cb.Items.Clear();
            StreamReader sr = new StreamReader(TenFile);
            string Line = sr.ReadLine();
            while (Line != null && Line != " ")
            {
                cb.Items.Add(Line);
                Line = sr.ReadLine();
            }
            LocDuLieuTrung(cb);
            sr.Close();
        }

        //loc du lieu trung trong listbox va xoa du lieu bi trung trong listbox
        public static void LocListBox(DataGridView dgr, ComboBox cb, byte chiso)
        {
            for (int i = dgr.RowCount - 2; i >= 0; i--)
            {
                string a = dgr[chiso, i].Value.ToString().ToLower().Trim();
                if (cb.Text.ToLower().Trim() != a)
                {
                    dgr.Rows.RemoveAt(i);
                }
            }
        }

        //loc du lieu trung trong combobox
        public void LocDuLieuTrung(ComboBox cb)
        {
            int flag;
            for (int j = 0; j < cb.Items.Count; ++j)
            {
                for (int i = j + 1; i < cb.Items.Count; ++i)
                {
                    flag = 0;
                    if (cb.Items[j].ToString() == cb.Items[i].ToString())
                    {
                        flag = 1;
                    }
                    if (flag == 1)
                    {
                        cb.Items.RemoveAt(i);
                    }
                }
            }
        }

    }
}
