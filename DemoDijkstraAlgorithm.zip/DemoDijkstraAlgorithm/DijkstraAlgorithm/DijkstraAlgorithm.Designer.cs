﻿namespace DijkstraAlgorithm
{
    partial class frmDijkstraAlgorithm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblXoaDong = new System.Windows.Forms.Label();
            this.btnChonLoaiDT = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnVe = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdbCohuong = new System.Windows.Forms.RadioButton();
            this.rdbVohuong = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvThongTinDT = new System.Windows.Forms.DataGridView();
            this.Canh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dau = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cuoi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrongSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnKiemTraLienThong = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.txtTrongSo = new System.Windows.Forms.TextBox();
            this.lblTrongSo = new System.Windows.Forms.Label();
            this.lblSoCanh = new System.Windows.Forms.Label();
            this.txtSoCanh = new System.Windows.Forms.TextBox();
            this.txtDinhCuoi = new System.Windows.Forms.TextBox();
            this.lblDinhCuoi = new System.Windows.Forms.Label();
            this.txtDinhDau = new System.Windows.Forms.TextBox();
            this.lblDinhDau = new System.Windows.Forms.Label();
            this.txtCanh = new System.Windows.Forms.TextBox();
            this.lblCanh = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvMinhHoaDuyet = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cbDinhxuatphat = new System.Windows.Forms.ComboBox();
            this.btnDuyet = new System.Windows.Forms.Button();
            this.lblDinhxuatphat = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgvDuongDiNN = new System.Windows.Forms.DataGridView();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.picDoThi = new System.Windows.Forms.PictureBox();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.picDuongDi = new System.Windows.Forms.PictureBox();
            this.tltInfo = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinDT)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMinhHoaDuyet)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDuongDiNN)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDoThi)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDuongDi)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(892, 100);
            this.panel1.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblXoaDong);
            this.groupBox5.Controls.Add(this.btnChonLoaiDT);
            this.groupBox5.Controls.Add(this.btnHuy);
            this.groupBox5.Controls.Add(this.btnCapNhat);
            this.groupBox5.Controls.Add(this.btnVe);
            this.groupBox5.Controls.Add(this.btnXoa);
            this.groupBox5.Controls.Add(this.btnSua);
            this.groupBox5.Controls.Add(this.btnThem);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(715, 100);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // lblXoaDong
            // 
            this.lblXoaDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblXoaDong.AutoSize = true;
            this.lblXoaDong.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXoaDong.ForeColor = System.Drawing.Color.Red;
            this.lblXoaDong.Location = new System.Drawing.Point(6, 82);
            this.lblXoaDong.Name = "lblXoaDong";
            this.lblXoaDong.Size = new System.Drawing.Size(0, 15);
            this.lblXoaDong.TabIndex = 7;
            // 
            // btnChonLoaiDT
            // 
            this.btnChonLoaiDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnChonLoaiDT.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChonLoaiDT.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnChonLoaiDT.Location = new System.Drawing.Point(615, 33);
            this.btnChonLoaiDT.Name = "btnChonLoaiDT";
            this.btnChonLoaiDT.Size = new System.Drawing.Size(90, 35);
            this.btnChonLoaiDT.TabIndex = 6;
            this.btnChonLoaiDT.Text = "&Chọn";
            this.tltInfo.SetToolTip(this.btnChonLoaiDT, "Chọn loại đồ thị!");
            this.btnChonLoaiDT.UseVisualStyleBackColor = true;
            this.btnChonLoaiDT.Click += new System.EventHandler(this.btnChonLoaiDT_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnHuy.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnHuy.Location = new System.Drawing.Point(514, 33);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(90, 35);
            this.btnHuy.TabIndex = 5;
            this.btnHuy.Text = "&Huỷ";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnCapNhat.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCapNhat.ForeColor = System.Drawing.Color.Blue;
            this.btnCapNhat.Location = new System.Drawing.Point(413, 33);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(90, 35);
            this.btnCapNhat.TabIndex = 4;
            this.btnCapNhat.Text = "&Cập Nhật";
            this.btnCapNhat.UseVisualStyleBackColor = true;
            this.btnCapNhat.Click += new System.EventHandler(this.btnCapNhat_Click);
            // 
            // btnVe
            // 
            this.btnVe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnVe.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVe.ForeColor = System.Drawing.Color.DeepPink;
            this.btnVe.Location = new System.Drawing.Point(312, 33);
            this.btnVe.Name = "btnVe";
            this.btnVe.Size = new System.Drawing.Size(90, 35);
            this.btnVe.TabIndex = 3;
            this.btnVe.Text = "&Vẽ";
            this.tltInfo.SetToolTip(this.btnVe, "Vẽ đồ thị hiện tại!");
            this.btnVe.UseVisualStyleBackColor = true;
            this.btnVe.Click += new System.EventHandler(this.btnVe_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnXoa.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoa.ForeColor = System.Drawing.Color.Red;
            this.btnXoa.Location = new System.Drawing.Point(211, 33);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(90, 35);
            this.btnXoa.TabIndex = 2;
            this.btnXoa.Text = "&Xoá";
            this.tltInfo.SetToolTip(this.btnXoa, "Xoá tất cả dữ liệu!");
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnSua.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSua.ForeColor = System.Drawing.Color.Gold;
            this.btnSua.Location = new System.Drawing.Point(110, 33);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(90, 35);
            this.btnSua.TabIndex = 1;
            this.btnSua.Text = "&Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThem
            // 
            this.btnThem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnThem.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem.ForeColor = System.Drawing.Color.Green;
            this.btnThem.Location = new System.Drawing.Point(9, 33);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(90, 35);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "&Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rdbCohuong);
            this.groupBox4.Controls.Add(this.rdbVohuong);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox4.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(715, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(177, 100);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tuỳ Chọn";
            // 
            // rdbCohuong
            // 
            this.rdbCohuong.AutoSize = true;
            this.rdbCohuong.CausesValidation = false;
            this.rdbCohuong.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCohuong.Location = new System.Drawing.Point(25, 52);
            this.rdbCohuong.Name = "rdbCohuong";
            this.rdbCohuong.Size = new System.Drawing.Size(126, 21);
            this.rdbCohuong.TabIndex = 1;
            this.rdbCohuong.Text = "Đồ thị có hướng";
            this.rdbCohuong.UseVisualStyleBackColor = true;
            this.rdbCohuong.CheckedChanged += new System.EventHandler(this.rdbCohuong_CheckedChanged);
            // 
            // rdbVohuong
            // 
            this.rdbVohuong.AutoSize = true;
            this.rdbVohuong.CausesValidation = false;
            this.rdbVohuong.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbVohuong.Location = new System.Drawing.Point(25, 27);
            this.rdbVohuong.Name = "rdbVohuong";
            this.rdbVohuong.Size = new System.Drawing.Size(127, 21);
            this.rdbVohuong.TabIndex = 0;
            this.rdbVohuong.Text = "Đồ thị vô hướng";
            this.rdbVohuong.UseVisualStyleBackColor = true;
            this.rdbVohuong.CheckedChanged += new System.EventHandler(this.rdbVohuong_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(243, 426);
            this.panel2.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvThongTinDT);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 426);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin đồ thị";
            // 
            // dgvThongTinDT
            // 
            this.dgvThongTinDT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvThongTinDT.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvThongTinDT.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvThongTinDT.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvThongTinDT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongTinDT.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Canh,
            this.Dau,
            this.Cuoi,
            this.TrongSo});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvThongTinDT.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvThongTinDT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThongTinDT.Location = new System.Drawing.Point(3, 19);
            this.dgvThongTinDT.Name = "dgvThongTinDT";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvThongTinDT.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvThongTinDT.RowHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvThongTinDT.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvThongTinDT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvThongTinDT.Size = new System.Drawing.Size(237, 208);
            this.dgvThongTinDT.TabIndex = 0;
            this.tltInfo.SetToolTip(this.dgvThongTinDT, "Click đúp một dòng để xoá!");
            this.dgvThongTinDT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvThongTinDT_CellClick);
            this.dgvThongTinDT.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvThongTinDT_CellDoubleClick);
            this.dgvThongTinDT.MouseLeave += new System.EventHandler(this.dgvThongTinDT_MouseLeave);
            this.dgvThongTinDT.MouseHover += new System.EventHandler(this.dgvThongTinDT_MouseHover);
            // 
            // Canh
            // 
            this.Canh.HeaderText = "Cạnh";
            this.Canh.Name = "Canh";
            this.Canh.ReadOnly = true;
            this.Canh.Width = 59;
            // 
            // Dau
            // 
            this.Dau.HeaderText = "Đầu";
            this.Dau.Name = "Dau";
            this.Dau.ReadOnly = true;
            this.Dau.Width = 54;
            // 
            // Cuoi
            // 
            this.Cuoi.HeaderText = "Cuối";
            this.Cuoi.Name = "Cuoi";
            this.Cuoi.ReadOnly = true;
            this.Cuoi.Width = 57;
            // 
            // TrongSo
            // 
            this.TrongSo.HeaderText = "Trọng Số";
            this.TrongSo.Name = "TrongSo";
            this.TrongSo.ReadOnly = true;
            this.TrongSo.Width = 81;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnKiemTraLienThong);
            this.groupBox6.Controls.Add(this.btnRefresh);
            this.groupBox6.Controls.Add(this.txtTrongSo);
            this.groupBox6.Controls.Add(this.lblTrongSo);
            this.groupBox6.Controls.Add(this.lblSoCanh);
            this.groupBox6.Controls.Add(this.txtSoCanh);
            this.groupBox6.Controls.Add(this.txtDinhCuoi);
            this.groupBox6.Controls.Add(this.lblDinhCuoi);
            this.groupBox6.Controls.Add(this.txtDinhDau);
            this.groupBox6.Controls.Add(this.lblDinhDau);
            this.groupBox6.Controls.Add(this.txtCanh);
            this.groupBox6.Controls.Add(this.lblCanh);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox6.Location = new System.Drawing.Point(3, 227);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(237, 196);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            // 
            // btnKiemTraLienThong
            // 
            this.btnKiemTraLienThong.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnKiemTraLienThong.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiemTraLienThong.ForeColor = System.Drawing.Color.Purple;
            this.btnKiemTraLienThong.Location = new System.Drawing.Point(149, 51);
            this.btnKiemTraLienThong.Name = "btnKiemTraLienThong";
            this.btnKiemTraLienThong.Size = new System.Drawing.Size(80, 28);
            this.btnKiemTraLienThong.TabIndex = 7;
            this.btnKiemTraLienThong.Text = "&KTLT";
            this.tltInfo.SetToolTip(this.btnKiemTraLienThong, "Kiểm tra tính liên thông của đồ thị hiện tại!");
            this.btnKiemTraLienThong.UseVisualStyleBackColor = true;
            this.btnKiemTraLienThong.Click += new System.EventHandler(this.btnKiemTraLienThong_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRefresh.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.ForeColor = System.Drawing.Color.Green;
            this.btnRefresh.Location = new System.Drawing.Point(149, 17);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(80, 28);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "&Refresh";
            this.tltInfo.SetToolTip(this.btnRefresh, "Đặt lại số cạnh!");
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // txtTrongSo
            // 
            this.txtTrongSo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTrongSo.Location = new System.Drawing.Point(74, 156);
            this.txtTrongSo.Name = "txtTrongSo";
            this.txtTrongSo.Size = new System.Drawing.Size(65, 23);
            this.txtTrongSo.TabIndex = 5;
            this.txtTrongSo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTrongSo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTrongSo_KeyUp);
            this.txtTrongSo.Leave += new System.EventHandler(this.txtTrongSo_Leave);
            // 
            // lblTrongSo
            // 
            this.lblTrongSo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTrongSo.AutoSize = true;
            this.lblTrongSo.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrongSo.Location = new System.Drawing.Point(7, 160);
            this.lblTrongSo.Name = "lblTrongSo";
            this.lblTrongSo.Size = new System.Drawing.Size(60, 15);
            this.lblTrongSo.TabIndex = 8;
            this.lblTrongSo.Text = "Trọng Số";
            // 
            // lblSoCanh
            // 
            this.lblSoCanh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSoCanh.AutoSize = true;
            this.lblSoCanh.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoCanh.Location = new System.Drawing.Point(7, 24);
            this.lblSoCanh.Name = "lblSoCanh";
            this.lblSoCanh.Size = new System.Drawing.Size(54, 15);
            this.lblSoCanh.TabIndex = 5;
            this.lblSoCanh.Text = "Số Cạnh";
            // 
            // txtSoCanh
            // 
            this.txtSoCanh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSoCanh.Location = new System.Drawing.Point(74, 20);
            this.txtSoCanh.Name = "txtSoCanh";
            this.txtSoCanh.Size = new System.Drawing.Size(65, 23);
            this.txtSoCanh.TabIndex = 1;
            this.txtSoCanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSoCanh.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSoCanh_KeyUp);
            this.txtSoCanh.Leave += new System.EventHandler(this.txtSoCanh_Leave);
            // 
            // txtDinhCuoi
            // 
            this.txtDinhCuoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinhCuoi.Location = new System.Drawing.Point(74, 122);
            this.txtDinhCuoi.Name = "txtDinhCuoi";
            this.txtDinhCuoi.Size = new System.Drawing.Size(65, 23);
            this.txtDinhCuoi.TabIndex = 4;
            this.txtDinhCuoi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDinhCuoi.Enter += new System.EventHandler(this.txtDinhCuoi_Enter);
            this.txtDinhCuoi.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDinhCuoi_KeyUp);
            this.txtDinhCuoi.Leave += new System.EventHandler(this.txtDinhCuoi_Leave);
            // 
            // lblDinhCuoi
            // 
            this.lblDinhCuoi.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDinhCuoi.AutoSize = true;
            this.lblDinhCuoi.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinhCuoi.Location = new System.Drawing.Point(7, 126);
            this.lblDinhCuoi.Name = "lblDinhCuoi";
            this.lblDinhCuoi.Size = new System.Drawing.Size(65, 15);
            this.lblDinhCuoi.TabIndex = 9;
            this.lblDinhCuoi.Text = "Đỉnh Cuối";
            // 
            // txtDinhDau
            // 
            this.txtDinhDau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinhDau.Location = new System.Drawing.Point(74, 88);
            this.txtDinhDau.Name = "txtDinhDau";
            this.txtDinhDau.Size = new System.Drawing.Size(65, 23);
            this.txtDinhDau.TabIndex = 3;
            this.txtDinhDau.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDinhDau.Enter += new System.EventHandler(this.txtDinhDau_Enter);
            this.txtDinhDau.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDinhDau_KeyUp);
            this.txtDinhDau.Leave += new System.EventHandler(this.txtDinhDau_Leave);
            // 
            // lblDinhDau
            // 
            this.lblDinhDau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblDinhDau.AutoSize = true;
            this.lblDinhDau.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinhDau.Location = new System.Drawing.Point(7, 92);
            this.lblDinhDau.Name = "lblDinhDau";
            this.lblDinhDau.Size = new System.Drawing.Size(63, 15);
            this.lblDinhDau.TabIndex = 6;
            this.lblDinhDau.Text = "Đỉnh Đầu";
            // 
            // txtCanh
            // 
            this.txtCanh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCanh.Location = new System.Drawing.Point(74, 54);
            this.txtCanh.Name = "txtCanh";
            this.txtCanh.Size = new System.Drawing.Size(65, 23);
            this.txtCanh.TabIndex = 2;
            this.txtCanh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCanh.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtCanh_KeyUp);
            this.txtCanh.Leave += new System.EventHandler(this.txtCanh_Leave);
            // 
            // lblCanh
            // 
            this.lblCanh.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCanh.AutoSize = true;
            this.lblCanh.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCanh.Location = new System.Drawing.Point(7, 58);
            this.lblCanh.Name = "lblCanh";
            this.lblCanh.Size = new System.Drawing.Size(37, 15);
            this.lblCanh.TabIndex = 5;
            this.lblCanh.Text = "Cạnh";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(243, 100);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 426);
            this.splitter1.TabIndex = 2;
            this.splitter1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(246, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 426);
            this.panel3.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvMinhHoaDuyet);
            this.groupBox2.Controls.Add(this.groupBox8);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(270, 426);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Minh hoạ các thao tác duyệt";
            // 
            // dgvMinhHoaDuyet
            // 
            this.dgvMinhHoaDuyet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvMinhHoaDuyet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvMinhHoaDuyet.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMinhHoaDuyet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvMinhHoaDuyet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMinhHoaDuyet.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvMinhHoaDuyet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMinhHoaDuyet.Location = new System.Drawing.Point(3, 19);
            this.dgvMinhHoaDuyet.Name = "dgvMinhHoaDuyet";
            this.dgvMinhHoaDuyet.ReadOnly = true;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMinhHoaDuyet.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvMinhHoaDuyet.RowHeadersVisible = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvMinhHoaDuyet.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvMinhHoaDuyet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMinhHoaDuyet.Size = new System.Drawing.Size(264, 208);
            this.dgvMinhHoaDuyet.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cbDinhxuatphat);
            this.groupBox8.Controls.Add(this.btnDuyet);
            this.groupBox8.Controls.Add(this.lblDinhxuatphat);
            this.groupBox8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox8.Location = new System.Drawing.Point(3, 227);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(264, 53);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            // 
            // cbDinhxuatphat
            // 
            this.cbDinhxuatphat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.cbDinhxuatphat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbDinhxuatphat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbDinhxuatphat.FormattingEnabled = true;
            this.cbDinhxuatphat.Location = new System.Drawing.Point(109, 15);
            this.cbDinhxuatphat.Name = "cbDinhxuatphat";
            this.cbDinhxuatphat.Size = new System.Drawing.Size(65, 23);
            this.cbDinhxuatphat.TabIndex = 3;
            this.cbDinhxuatphat.TextChanged += new System.EventHandler(this.cbDinhxuatphat_TextChanged);
            // 
            // btnDuyet
            // 
            this.btnDuyet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btnDuyet.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDuyet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnDuyet.Location = new System.Drawing.Point(179, 9);
            this.btnDuyet.Name = "btnDuyet";
            this.btnDuyet.Size = new System.Drawing.Size(80, 35);
            this.btnDuyet.TabIndex = 9;
            this.btnDuyet.Text = "&Duyệt";
            this.tltInfo.SetToolTip(this.btnDuyet, "Tìm đường đi ngắn nhất tới các đỉnh từ một đỉnh bất kỳ!");
            this.btnDuyet.UseVisualStyleBackColor = true;
            this.btnDuyet.Click += new System.EventHandler(this.btnDuyet_Click);
            // 
            // lblDinhxuatphat
            // 
            this.lblDinhxuatphat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblDinhxuatphat.AutoSize = true;
            this.lblDinhxuatphat.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinhxuatphat.Location = new System.Drawing.Point(6, 17);
            this.lblDinhxuatphat.Name = "lblDinhxuatphat";
            this.lblDinhxuatphat.Size = new System.Drawing.Size(98, 15);
            this.lblDinhxuatphat.TabIndex = 8;
            this.lblDinhxuatphat.Text = "Đỉnh Xuất Phát";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgvDuongDiNN);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox7.Location = new System.Drawing.Point(3, 280);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(264, 143);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Đường đi ngắn nhất đến các đỉnh";
            // 
            // dgvDuongDiNN
            // 
            this.dgvDuongDiNN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDuongDiNN.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDuongDiNN.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDuongDiNN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvDuongDiNN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDuongDiNN.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgvDuongDiNN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDuongDiNN.Location = new System.Drawing.Point(3, 19);
            this.dgvDuongDiNN.Name = "dgvDuongDiNN";
            this.dgvDuongDiNN.ReadOnly = true;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDuongDiNN.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvDuongDiNN.RowHeadersVisible = false;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvDuongDiNN.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvDuongDiNN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDuongDiNN.Size = new System.Drawing.Size(258, 121);
            this.dgvDuongDiNN.TabIndex = 1;
            // 
            // splitter2
            // 
            this.splitter2.Location = new System.Drawing.Point(516, 100);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(3, 426);
            this.splitter2.TabIndex = 4;
            this.splitter2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.picDoThi);
            this.groupBox3.Controls.Add(this.splitter3);
            this.groupBox3.Controls.Add(this.groupBox9);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(519, 100);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(373, 426);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Đồ thị";
            // 
            // picDoThi
            // 
            this.picDoThi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picDoThi.Location = new System.Drawing.Point(3, 19);
            this.picDoThi.Name = "picDoThi";
            this.picDoThi.Size = new System.Drawing.Size(367, 205);
            this.picDoThi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDoThi.TabIndex = 2;
            this.picDoThi.TabStop = false;
            this.picDoThi.Paint += new System.Windows.Forms.PaintEventHandler(this.picDoThi_Paint);
            // 
            // splitter3
            // 
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(3, 224);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(367, 3);
            this.splitter3.TabIndex = 1;
            this.splitter3.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.picDuongDi);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox9.Location = new System.Drawing.Point(3, 227);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(367, 196);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Đường đi ngắn nhất";
            // 
            // picDuongDi
            // 
            this.picDuongDi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picDuongDi.Location = new System.Drawing.Point(3, 19);
            this.picDuongDi.Name = "picDuongDi";
            this.picDuongDi.Size = new System.Drawing.Size(361, 174);
            this.picDuongDi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDuongDi.TabIndex = 3;
            this.picDuongDi.TabStop = false;
            // 
            // tltInfo
            // 
            this.tltInfo.ShowAlways = true;
            // 
            // frmDijkstraAlgorithm
            // 
            this.AcceptButton = this.btnChonLoaiDT;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnHuy;
            this.ClientSize = new System.Drawing.Size(892, 526);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.splitter2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmDijkstraAlgorithm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Demo Dijkstra Algorithm ";
            this.Load += new System.EventHandler(this.frmDijkstraAlgorithm_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongTinDT)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMinhHoaDuyet)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDuongDiNN)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picDoThi)).EndInit();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picDuongDi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnVe;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.RadioButton rdbCohuong;
        private System.Windows.Forms.RadioButton rdbVohuong;
        private System.Windows.Forms.Button btnCapNhat;
        private System.Windows.Forms.DataGridView dgvThongTinDT;
        private System.Windows.Forms.DataGridView dgvMinhHoaDuyet;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtTrongSo;
        private System.Windows.Forms.Label lblTrongSo;
        private System.Windows.Forms.TextBox txtDinhCuoi;
        private System.Windows.Forms.Label lblDinhCuoi;
        private System.Windows.Forms.TextBox txtDinhDau;
        private System.Windows.Forms.Label lblDinhDau;
        private System.Windows.Forms.TextBox txtCanh;
        private System.Windows.Forms.Label lblCanh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Canh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dau;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cuoi;
        private System.Windows.Forms.DataGridViewTextBoxColumn TrongSo;
        private System.Windows.Forms.TextBox txtSoCanh;
        private System.Windows.Forms.Label lblSoCanh;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnDuyet;
        private System.Windows.Forms.Label lblDinhxuatphat;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgvDuongDiNN;
        private System.Windows.Forms.Button btnChonLoaiDT;
        private System.Windows.Forms.Button btnKiemTraLienThong;
        private System.Windows.Forms.Label lblXoaDong;
        private System.Windows.Forms.ToolTip tltInfo;
        private System.Windows.Forms.ComboBox cbDinhxuatphat;
        private System.Windows.Forms.PictureBox picDoThi;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox picDuongDi;
    }
}

